import { Component, OnInit } from '@angular/core';
export interface PeriodicElement {
  name: string;
  position: number;
  weight: number;
  symbol: string;
}

export interface Compte {
  numeroCompte: string;
  intitule: string;
  solde: string;
  dateOperation: string
}

export interface Virement {
  id: string;
  compteExp: string;
  compteDest: string;
  montant: string,
  dateOperation: string,
  statut: string
}


// const mesComptes: Compte[] = [
//   { numeroCompte: "67139051493590", intitule: "M. LAHMIDI Oussama", solde: "120", dateOperation: "12 Mars 2020" },
//   { numeroCompte: "67139051493590", intitule: "M. LAHMIDI Oussama", solde: "120", dateOperation: "12 Mars 2020" },
//   { numeroCompte: "67139051493590", intitule: "M. LAHMIDI Oussama", solde: "120", dateOperation: "12 Mars 2020" },
//   { numeroCompte: "67139051493590", intitule: "M. LAHMIDI Oussama", solde: "120", dateOperation: "12 Mars 2020" },
// ];

const ELEMENT_DATA: PeriodicElement[] = [
  {position: 1, name: 'Hydrogen', weight: 1.0079, symbol: 'H'},
  {position: 2, name: 'Helium', weight: 4.0026, symbol: 'He'},
  {position: 3, name: 'Lithium', weight: 6.941, symbol: 'Li'},
  {position: 4, name: 'Beryllium', weight: 9.0122, symbol: 'Be'},
  {position: 5, name: 'Boron', weight: 10.811, symbol: 'B'},
];

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  constructor() { }
  displayedColumns: string[] = ['position', 'name', 'weight', 'symbol'];
  dataSource = ELEMENT_DATA;

  compteColumns: string[] = ['numeroCompte', 'intitule', 'solde', 'dateOperation'];
  mesComptes: Compte[] = [
    { numeroCompte: "67139051493590", intitule: "M. LAHMIDI Oussama", solde: "120", dateOperation: "12 Mars 2020" },
    { numeroCompte: "67139051493590", intitule: "M. LAHMIDI Oussama", solde: "120", dateOperation: "12 Mars 2020" },
    { numeroCompte: "67139051493590", intitule: "M. LAHMIDI Oussama", solde: "120", dateOperation: "12 Mars 2020" },
    { numeroCompte: "67139051493590", intitule: "M. LAHMIDI Oussama", solde: "120", dateOperation: "12 Mars 2020" },
  ];

  virementColumns: string[] = ['id', 'comptexp', 'comptedest', 'montant', 'dateOper', 'statut'];
  mesVirements: Virement[] = [
    { id: "42137235090", compteExp: '67139051493590', compteDest: "791045132", montant: "100", dateOperation: "12 Mars 2020", statut: "VALID" },
    { id: "42137235090", compteExp: '67139051493590', compteDest: "791045132", montant: "100", dateOperation: "12 Mars 2020", statut: "VALID" },
    { id: "42137235090", compteExp: '67139051493590', compteDest: "791045132", montant: "100", dateOperation: "12 Mars 2020", statut: "VALID" },
  ]
  ngOnInit() {
  }

}
