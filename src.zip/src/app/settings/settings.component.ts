import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
export interface Compte {
  numeroCompte: string;
  intitule: string;
  solde: string;
  dateOperation: string
}
const ELEMENT_DATA: Compte[] = [
  { numeroCompte: "67139051493590", intitule: "M. LAHMIDI Oussama", solde: "120", dateOperation: "12 Mars 2020" },
  { numeroCompte: "67139051493590", intitule: "M. LAHMIDI Oussama", solde: "120", dateOperation: "12 Mars 2020" },
  { numeroCompte: "67139051493590", intitule: "M. LAHMIDI Oussama", solde: "120", dateOperation: "12 Mars 2020" },
  { numeroCompte: "67139051493590", intitule: "M. LAHMIDI Oussama", solde: "120", dateOperation: "12 Mars 2020" },
];
@Component({
  selector: 'app-settings',
  templateUrl: './settings.component.html',
  styleUrls: ['./settings.component.css']
})
export class SettingsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
   
  }
  displayedColumns: string[] = ['numeroCompte', 'intitule', 'solde', 'dateOperation','actions'];
  dataSource = ELEMENT_DATA;
  

}
