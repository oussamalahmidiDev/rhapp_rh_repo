export interface Compte {
      numeroCompte: string;
      intitule: string;
      solde: string;
      dateOperation: string
    }