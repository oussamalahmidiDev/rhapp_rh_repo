// import{uuid}from'../util/uuid';

export class User {
  id: string;
  constructor(public name: string, 
      public avatarSrc: string, 
      public email : string,
      public tel : string,
      public dateNaissance: string,
      public adresse: string) {
    this.id = Math.random().toString();
  }
}
