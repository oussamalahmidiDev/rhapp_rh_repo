import { Injectable } from '@angular/core';
import { User } from '../models/user';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  currentUser: User;
  constructor(private router: Router) {
    
    this.currentUser = new User("Lahmidi Oussama", "https://picsum.photos/300", "ou@g.c", "0634349912", "Nº 153 Quartier Lorem Ipsum", "23/02/1998");
  }

  login(email: string, password: string): boolean {
    if (email === 'email' && password === 'pass') {
      localStorage.setItem('loggedin', "1");
      this.router.navigate(['home']);
      return true;
    }
    return false;
  }

  logout(): any { 
    localStorage.removeItem('loggedin');
    this.router.navigate(['']);
  }

  isLoggedIn(): boolean {
    return localStorage.getItem("loggedin") == "1";
    }
}
export const AUTH_PROVIDERS:Array<any>=[
  { provide: UserService, useClass: UserService }
  ];
