import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { UserService } from "../../services/user.service";

@Component({
  selector: "app-welcome-page",
  templateUrl: "./welcome-page.component.html",
  styleUrls: ["./welcome-page.component.css"]
})
export class WelcomePageComponent implements OnInit {
  constructor(private router: Router, private authService: UserService) {}

  ngOnInit() {}

  message: string;

  authenticate(): void {
    localStorage.setItem("loggedin", "1");
    this.router.navigateByUrl("/dashboard");
  }
  login(email: string, password: string): boolean {
    this.message = "";
    if (!this.authService.login(email, password)) {
      this.message = "Incorrect credentials.";
      console.log(email, password);
      setTimeout(
        function() {
          this.message = "";
        }.bind(this),
        2500
      );
    }
    return false;
  }
}
